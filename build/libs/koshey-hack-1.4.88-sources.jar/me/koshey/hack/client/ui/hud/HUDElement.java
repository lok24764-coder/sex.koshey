package me.koshey.hack.client.ui.hud;

public abstract class HUDElement {
    private final String name;
    private boolean enabled = true;
    
    public HUDElement(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
