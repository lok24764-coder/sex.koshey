package me.koshey.hack.client.ui.clickgui;

import me.koshey.hack.client.KosheyClient;
import me.koshey.hack.client.font.CustomFont;
import me.koshey.hack.client.module.Module;
import me.koshey.hack.client.setting.BooleanSetting;
import me.koshey.hack.client.setting.ModeSetting;
import me.koshey.hack.client.setting.NumberSetting;
import me.koshey.hack.client.setting.Setting;

public class ModuleButton {
    private final Module module;
    private final CategoryFrame parent;
    private boolean expanded = false;
    private static final int MODULE_HEIGHT = 16;
    private static final int SETTING_HEIGHT = 14;
    
    public ModuleButton(Module module, CategoryFrame parent) {
        this.module = module;
        this.parent = parent;
    }
    
    public void render(net.minecraft.client.gui.GuiGraphicsExtractor drawContext, int mouseX, int mouseY, int x, int y, int width) {
        int bgColor = module.isEnabled() ? 0xFF44AA44 : 0xFF222222;
        me.koshey.hack.client.render.RenderUtil.fill(drawContext, x, y, x + width, y + MODULE_HEIGHT, bgColor);
        me.koshey.hack.client.render.RenderUtil.drawString(drawContext, module.getName(), x + 5, y + 4, 0xFFFFFFFF);
        
        if (expanded) {
            int offsetY = MODULE_HEIGHT;
            for (Setting<?> setting : module.getSettings()) {
                me.koshey.hack.client.render.RenderUtil.fill(drawContext, x, y + offsetY, x + width, y + offsetY + SETTING_HEIGHT, 0xFF111111);
                
                String text = setting.getName();
                if (setting instanceof BooleanSetting bool) {
                    text += ": " + (bool.getValue() ? "On" : "Off");
                } else if (setting instanceof NumberSetting num) {
                    text += ": " + String.format("%.1f", num.getValue());
                } else if (setting instanceof ModeSetting mode) {
                    text += ": " + mode.getValue();
                }
                
                me.koshey.hack.client.render.RenderUtil.drawString(drawContext, text, x + 10, y + offsetY + 3, 0xFFAAAAAA);
                offsetY += SETTING_HEIGHT;
            }
        }
    }
    
    public boolean mouseClicked(double mouseX, double mouseY, int button, int x, int y, int width) {
        if (isHovered(mouseX, mouseY, x, y, width, MODULE_HEIGHT)) {
            if (button == 0) {
                module.toggle();
                return true;
            } else if (button == 1) {
                expanded = !expanded;
                return true;
            }
        }
        
        if (expanded && !module.getSettings().isEmpty()) {
            int offsetY = MODULE_HEIGHT;
            for (Setting<?> setting : module.getSettings()) {
                if (isHovered(mouseX, mouseY, x, y + offsetY, width, SETTING_HEIGHT)) {
                    if (button == 0) {
                        if (setting instanceof BooleanSetting bool) {
                            bool.toggle();
                        } else if (setting instanceof ModeSetting mode) {
                            mode.cycle();
                        }
                        return true;
                    }
                }
                offsetY += SETTING_HEIGHT;
            }
        }
        
        return false;
    }
    
    public int getHeight() {
        int height = MODULE_HEIGHT;
        if (expanded) {
            height += module.getSettings().size() * SETTING_HEIGHT;
        }
        return height;
    }
    
    private boolean isHovered(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
}
