package me.koshey.hack.client.ui.hud;

import me.koshey.hack.client.event.Listener;
import me.koshey.hack.client.event.impl.RenderHUDEvent;
import me.koshey.hack.client.ui.hud.impl.KeybindsHUD;
import me.koshey.hack.client.ui.hud.impl.TargetHUD;
import me.koshey.hack.client.ui.hud.impl.WatermarkHUD;

import java.util.ArrayList;
import java.util.List;

public class HUDManager implements Listener {
    private final List<HUDElement> elements = new ArrayList<>();
    
    public HUDManager() {
        elements.add(new WatermarkHUD());
        elements.add(new TargetHUD());
        elements.add(new KeybindsHUD());
    }
    
    @Override
    public void onRenderHUD(RenderHUDEvent event) {
        for (HUDElement element : elements) {
            if (element.isEnabled()) {
                
            }
        }
    }
    
    public List<HUDElement> getElements() {
        return elements;
    }
}
