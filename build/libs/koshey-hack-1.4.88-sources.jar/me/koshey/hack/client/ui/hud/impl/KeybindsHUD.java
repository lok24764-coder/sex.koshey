package me.koshey.hack.client.ui.hud.impl;

import me.koshey.hack.client.ui.hud.HUDElement;

public class KeybindsHUD extends HUDElement {
    public KeybindsHUD() {
        super("Keybinds");
    }
}
