package me.koshey.hack.client.ui.hud.impl;

import me.koshey.hack.client.ui.hud.HUDElement;

public class WatermarkHUD extends HUDElement {
    public WatermarkHUD() {
        super("Watermark");
    }
}
