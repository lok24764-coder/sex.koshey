package me.koshey.hack.client.ui.hud.impl;

import me.koshey.hack.client.ui.hud.HUDElement;

public class TargetHUD extends HUDElement {
    public TargetHUD() {
        super("TargetHUD");
    }
}
