package me.koshey.hack.client.font;

import java.awt.*;

public class FontManager {
    private final CustomFont medium;
    private final CustomFont bold;
    private final CustomFont small;
    private final CustomFont large;
    
    public FontManager() {
        Font baseFont = new Font("Arial", Font.PLAIN, 18);
        this.medium = new CustomFont(baseFont);
        this.bold = new CustomFont(baseFont.deriveFont(Font.BOLD));
        this.small = new CustomFont(baseFont.deriveFont(16f));
        this.large = new CustomFont(baseFont.deriveFont(Font.BOLD, 24f));
    }
    
    public CustomFont getFont(String name) {
        return medium;
    }
    
    public CustomFont getMedium() {
        return medium;
    }
    
    public CustomFont getBold() {
        return bold;
    }
    
    public CustomFont getSmall() {
        return small;
    }
    
    public CustomFont getLarge() {
        return large;
    }
}
