package me.koshey.hack.client.font;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;

public class CustomFont {
    private final java.awt.Font font;
    
    public CustomFont(java.awt.Font font) {
        this.font = font;
    }
    
    public float getStringWidth(String text) {
        Font mcFont = Minecraft.getInstance().font;
        return mcFont.width(text);
    }
    
    public float getHeight() {
        return 9;
    }
}
