package me.koshey.hack.client.module.impl;

import me.koshey.hack.client.module.Module;

public class HUDModule extends Module {
    public HUDModule() {
        super("HUD", "Displays HUD elements", Category.RENDER);
        setEnabled(true);
    }
}
